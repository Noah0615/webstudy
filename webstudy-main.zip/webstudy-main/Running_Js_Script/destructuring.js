const scores = [997979, 897997, 868686, 767579, 543671, 242424, 141414]

const highScore = scores[0];
const secondHighScore = scores[i];

const [gold, silver, bronze, ...everyoneElse] = scores;
