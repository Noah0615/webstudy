const math = require('./math');
// console.log(math.PI);
// console.log('Hello, world!');

const cats = require('./shelter');
console.log("REQUIRED AN ENTIRE DIRECTORY!", cats);